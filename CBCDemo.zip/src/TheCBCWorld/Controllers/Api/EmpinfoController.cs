using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TheWorld.Models;
using TheWorld.Services;
using TheWorld.ViewModels;

namespace TheWorld.Controllers.Api
{
  [Route("/api/employee/{employeeName}/Employee")]
  public class EmpinfoController : Controller
  {
        private object newEmpinfo;
        private object result;
        private ILogger<EmpinfoController> _logger;
    private IWorldRepository _repository;

    public EmpinfoController(IWorldRepository repository,
      ILogger<EmpinfoController> logger)
    {
      _repository = repository;
      _logger = logger;
      
    }

    [HttpGet("")]
    public IActionResult Get(string employeeName)
    {
      try
      {
        var Employee = _repository.GetEmployeeByName(employeeName, User.Identity.Name);

        return Ok(Mapper.Map<IEnumerable<EmpinfoViewModel>>(employee.Empinfo.OrderBy(s => s.Order).ToList()));
      }
      catch (Exception ex)
      {
        _logger.LogError("Failed to get Employee: {0}", ex);
      }

      return BadRequest("Failed to get Employee");
    }

    [HttpPost("")]
    public async Task<IActionResult> Post(string EmployeeName, [FromBody]EmpinfoViewModel vm)
    {
      try
      {
        // If the VM is valid
        if (ModelState.IsValid)
        {
          var newEmployee = Mapper.Map<EmpInfo>(vm);

          // Lookup the Service
          
          if (!result.Success)
          {
            _logger.LogError(result.Message);
          }
          else
          {
            // To Do

            // Save to the Database
            _repository.AddEmpinfo(EmployeeName, User.Identity.Name, newEmpinfo);

            if (await _repository.SaveChangesAsync())
            {
              return Created($"/api/Employee/{EmployeeName}/impinfo/{newEmpinfo.Name}",
                Mapper.Map<EmpinfoViewModel>(newEmpinfo));
            }
          }
        }
      }
      catch (Exception ex)
      {
        _logger.LogError("Failed to save new Empinfo: {0}", ex);
      }

      return BadRequest("Failed to save new Empino");
    }
  }
}
