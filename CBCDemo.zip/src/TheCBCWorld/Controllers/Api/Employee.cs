using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TheWorld.Models;
using TheWorld.ViewModels;

namespace TheCBCWorld.Controllers.Api
{
  [Route("api/Employee")]
  [Authorize]
  public class Employee : Controller
  {
    private ILogger<Employee> _logger;
    private IWorldRepository _repository;

    public Employee(IWorldRepository repository, ILogger<Employee> logger)
    {
      _repository = repository;
      _logger = logger;
    }

    [HttpGet("")]
    public IActionResult Get()
    {
      try
      {
        var results = _repository.GetEmployeeByUsername(User.Identity.Name);

        return Ok(Mapper.Map<IEnumerable<EmployeeViewModel>>(results));
      }
      catch (Exception ex)
      {
        _logger.LogError($"Failed to get All Employee: {ex}");

        return BadRequest("Error occurred");
      }
    }

    [HttpPost("")]
    public async Task<IActionResult> Post([FromBody]EmployeeViewModel theEmployee)
    {
      if (ModelState.IsValid)
      {
        // Save to the Database
        var newEmployee = Mapper.Map<TheWorld.Models.Employee>(theEmployee);

        newEmployee.UserName = User.Identity.Name;

        _repository.AddEmployee(newEmployee);

        if (await _repository.SaveChangesAsync())
        {
          return Created($"api/employee/{theEmployee.Name}", Mapper.Map<EmployeeViewModel>(newEmployee));
        }
      }

      return BadRequest("Failed to save the Employee");
    }
  }
}
