﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace TheWorld.Models
{
  public interface IWorldRepository
  {
    IEnumerable<Employee> GetAllEmployee();
    Employee GetEmployeeByName(string employeeName, string username);

    void AddEmployee(Employee employee);
    void AddEmpinfo(string employeeName, string username, EmpInfo newEmpinfo);

    Task<bool> SaveChangesAsync();
    object GetEmployeeByUsername(string name);
  }
}