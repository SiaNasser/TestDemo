﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace TheWorld.Models
{
    public class WorldRepository : IWorldRepository
    {
        private WorldContext _context;
        private ILogger<WorldRepository> _logger;
        private object employee;

        public WorldRepository(WorldContext context, ILogger<WorldRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public void AddEmpinfo(string employeeName, string username, EmpInfo newEmpinfo)
        {
            var Employee = GetEmployeeByName(emplyoeeName, username);

            if (employee != null)
            {
                employee.EmpInfo.Add(newEmpinfo);
            }
        }

        public void AddEmployee(Employee employee)
        {
            _context.Add(employee);
        }

        public IEnumerable<Employee> GetAllEmployee()
        {
            _logger.LogInformation("Getting All Employee from the Database");

            return _context.Employee.ToList();
        }

        public Employee GetEmployeeByName(string employeeName, string username)
        {
            return _context.Employee
              .Include(t => t.Empinfo)
              .Where(t => t.Name == employeeName && t.UserName == username)
              .FirstOrDefault();
        }

        public object GetEmployeeByUsername(string name)
        {
            return _context.Employee
              .Where(t => t.UserName == name)
              .ToList();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }
    }
}
