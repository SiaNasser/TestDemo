// app-Emplyee.js
(function () {

  "use strict";

  // Creating the Module
  angular.module("app-Employees", ["simpleControls", "ngRoute"])
    .config(function ($routeProvider) {

      $routeProvider.when("/", {
        controller: "EmployeesController",
        controllerAs: "vm",
        templateUrl: "/views/EmployeesView.html"
      });

      $routeProvider.when("/editor/:EmployeeName", {
        controller: "EmployeeEditorController",
        controllerAs: "vm",
        templateUrl: "/views/EmployeeEditorView.html"
      });

      $routeProvider.otherwise({ redirectTo: "/" });

    });

})();