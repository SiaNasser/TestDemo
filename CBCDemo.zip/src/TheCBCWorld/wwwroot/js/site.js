// site.js
(function () {
 

    var $sidebarAndWrapper = $("#sidebar,#wrapper");
    var $icon = $("#sidebarToggle i.fa");


    $("#sidebarToggle").on("click", function () {
        $sidebarAndWrapper.toggleClass("display-sidebar");
        if ($sidebarAndWrapper.hasClass("display-sidebar")) {
            $(this).text("<");
        } else {
            $(this).text(">");
        }
    });

 

})();

