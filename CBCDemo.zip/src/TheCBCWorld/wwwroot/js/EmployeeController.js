// employeeController.js
(function () {

  "use strict";

  // Getting the existing module
  angular.module("app-employee")
    .controller("employeeController", employeeController);

  function employeeController($http) {

    var vm = this;

    vm.employeeController = [];

    vm.newEmployee = {};

    vm.errorMessage = "";
    vm.isBusy = true;

    $http.get("/api/employee")
      .then(function (response) {
        // Success
        angular.copy(response.data, vm.employeeControllers);
      }, function (error) {
        // Failure
        vm.errorMessage = "Failed to load data: " + error;
      })
      .finally(function () {
        vm.isBusy = false;
      });

    vm.addEmployee = function () {

      vm.isBusy = true;
      vm.errorMessage = "";

      $http.post("/api/employee", vm.newEmployee)
        .then(function (response) {
          // success
          vm.employee.push(response.data);
          vm.newEmployee = {};
        }, function () {
          // failure
          vm.errorMessage = "Failed to save new Employee";
        })
        .finally(function () {
          vm.isBusy = false;
        });

    };



  }

})();