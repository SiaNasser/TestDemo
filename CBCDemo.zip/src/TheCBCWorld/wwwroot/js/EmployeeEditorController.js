// EmployeeEditorController.js
(function () {
  "use strict";

  angular.module("app-Employees")
    .controller("EmployeeEditorController", EmployeeEditorController);

  function EmployeeEditorController($routeParams, $http) {
    var vm = this;

    vm.EmployeeName = $routeParams.EmployeeName;
    vm.Empinfos = [];
    vm.errorMessage = "";
    vm.isBusy = true;
    vm.newEmpinfo = {};

    var url = "/api/Employees/" + vm.EmployeeName + "/Empinfos";

    $http.get(url)
      .then(function (response) {
        // success
        angular.copy(response.data, vm.Empinfos);
        _showMap(vm.Empinfos);
      }, function (err) {
        // failure
        vm.errorMessage = "Failed to load Employee";
      })
      .finally(function () {
        vm.isBusy = false;
      });

    vm.addEmpinfo = function () {

      vm.isBusy = true;

      $http.post(url, vm.newEmpinfo)
        .then(function (response) {
          // success
          vm.Empinfos.push(response.data);
          _showMap(vm.Empinfos);
          vm.newEmpinfo = {};
        }, function (err) {
          // failure
          vm.errorMessage = "Failed to add new Employee";
        })
        .finally(function () {
          vm.isBusy = false;
        });

    };
  }

  function _showMap(Empinfos) {

    if (Empinfos && Empinfos.length > 0) {

      var mapEmpinfos = _.map(Empinfos, function (item) {
        return {
          lat: item.latitude,
          long: item.longitude,
          info: item.name
        };
      });

      // Show More
      travelMap.createMap({
        Empinfos: mapEmpinfos,
        selector: "#map",
        currentEmpinfo: 1,
        initialZoom: 3
      });

    }

  }

})();