using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheWorld.ViewModels
{
  public class EmpinfoViewModel
  {
    [Required]
    [StringLength(100, MinimumLength = 5)]
    public string Name { get; set; }

   
    [Required]
    public int Order { get; set; }

    [Required]
    public DateTime Started { get; set; }
    public int Salary { get; set; }
    public int Benefit { get; set; }
    public int Vacationdays { get; set; }
    }
}
